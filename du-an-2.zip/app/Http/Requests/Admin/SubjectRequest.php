<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
 
class SubjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'subject_name' => 'required|min:3|max:25',
            'image' => 'nullable|mimes:jpeg,png,jpg,gif,svg',
        ];
    }

    public function messages()
    {
        
        return [
            'required' => ':attribute không được để trống',
            'mimes' => ':attribute không đúng định dạng ' ,
            'min' => ':attribute không được nhỏ hơn :min ký tự',
            'max' => ':attribute không được lớn hơn :max ký tự',
        ];
    }

    public function attributes(){
        return [
            'subject_name' => 'Tên Bộ Môn',
            'description' => 'Mô tả',
            'image' => 'Ảnh'
        ];
    }
}
