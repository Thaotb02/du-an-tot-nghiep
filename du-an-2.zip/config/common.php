<?php 

return [
	'status' =>['Public'=>2,'Hidden'=>1],
	'role' =>['member'=>1,'pt'=>2,'admin'=>3]

]
?>